package com.ims.setting;

public class Globalvar {

    public static final String EXTRA_MAKANAN = "extra_makanan";
    public static final String EXTRA_PEDAS = "extra_pedas";
    public static final String EXTRA_CHK1 = "extra_chk1";
    public static final String EXTRA_CHK2 = "extra_chk2";
    public static final String EXTRA_CHK3 = "extra_chk3";
    public static final String EXTRA_CHK4 = "extra_chk4";

}
